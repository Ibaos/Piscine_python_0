print("Le package 'mon_package' a été chargé")

__all__ = ["math_utils", "stats_utils"]