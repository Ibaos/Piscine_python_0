from setuptools import setup, find_packages

setup(
    name='ft_package',
    version='1.0.0',
    packages=find_packages(),
    description='Un package de mathématiques simples',
    author='Bhumeau',
    author_email='stephane.robert@protonmail.com',
    url='https://github.com/stephane-robert/mon_module',
	licence="MIT",
	python_requires='>=3.10',
	install_requires=[],
)